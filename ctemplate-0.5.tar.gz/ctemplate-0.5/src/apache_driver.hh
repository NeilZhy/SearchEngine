#include "htpl_driver.h"

class apache_driver: public htpl_driver {
public:
  apache_driver();
  virtual void start(FILE* out_, FILE* hout_);
  virtual void finish_header();
  virtual void out_static_block(const char* text, int textlen);
  virtual void flush_static_blocks();
  virtual void out_dynamic_block(const char* text, int textlen);
  virtual void out_printf_block(const char* text, int textlen);
private:
  int static_out; //counter of bytes gone static
};
