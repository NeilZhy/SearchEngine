#ifndef __SEARCH_H__
#define __SEARCH_H__

#include "wiser.h"

void search(wiser_env *env, const char *query);

#endif /* __SEARCH_H__ */
